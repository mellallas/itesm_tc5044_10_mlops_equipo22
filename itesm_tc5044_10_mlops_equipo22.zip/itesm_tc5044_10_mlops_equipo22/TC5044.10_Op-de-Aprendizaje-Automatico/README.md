# TC5044.10_Op-de-Aprendizaje-Autom-tico
Operaciones de Aprendizaje Automático es la disciplina que integra, automatiza y gestiona el ciclo de vida de modelos de aprendizaje automático en entornos de producción, repositorio diseñado para alojar las prácticas y trbajos relacionados.
